import React, { useEffect, useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { AppConfigRecord } from '../types/movie';
import { DEFAULT_ADSTERRA_ZONE_KEY } from '../utils/securityValidator';

interface NonIntrusiveBannerAdProps {
  config: AppConfigRecord;
  placement?: 'home-top' | 'home-native' | 'player-bottom';
}

/**
 * Strict Banner Ads & Native Banner Ads Component:
 * 1. ONLY renders on allowed non-intrusive placements:
 *    - Home Top Banner (`home-top`)
 *    - Home Native Banner (`home-native`)
 *    - Movie Player Bottom (`player-bottom`)
 * 2. Employs clean same-origin frame isolation (`/adsterra-frame.html`) so Adsterra scripts
 *    render real visual ads with full responsive scaling.
 * 3. NO popunders or click-hijacks: the main app UI and buttons remain completely free of ad click triggers.
 * 4. Silently hides if ad blocker is active (`adStatus === 'blocked'` returns `null` with no ugly broken boxes).
 */
export const NonIntrusiveBannerAd: React.FC<NonIntrusiveBannerAdProps> = ({
  config,
  placement = 'home-top',
}) => {
  const [adStatus, setAdStatus] = useState<'loading' | 'loaded' | 'blocked'>('loading');
  const [frameKey, setFrameKey] = useState<number>(0);

  const activeZoneKey = config.adsterra_banner_key || DEFAULT_ADSTERRA_ZONE_KEY;

  useEffect(() => {
    if (!config.is_ads_enabled) return;

    const handleFrameMessage = (event: MessageEvent) => {
      if (event.data && event.data.type === 'ADSTERRA_STATUS') {
        if (event.data.status === 'blocked') {
          // Silently ignore if blocked by ad-blocker — never show error banner
          setAdStatus('blocked');
        } else if (event.data.status === 'loaded') {
          setAdStatus('loaded');
        }
      }
    };
    window.addEventListener('message', handleFrameMessage);
    return () => window.removeEventListener('message', handleFrameMessage);
  }, [config.is_ads_enabled]);

  // Silently hide if ads are disabled or if ad-blocker blocked the script
  if (!config.is_ads_enabled || adStatus === 'blocked') {
    return null;
  }

  const slotLabel =
    placement === 'home-native'
      ? 'Sponsored Native Banner'
      : placement === 'player-bottom'
      ? 'Sponsored Player Banner'
      : 'Sponsored Banner';

  const isNative = placement === 'home-native';
  const iframeHeightClass = isNative ? 'h-[140px] sm:h-[160px]' : 'h-[90px] sm:h-[100px]';

  return (
    <div
      data-testid={`non-intrusive-banner-ad-${placement}`}
      aria-label={slotLabel}
      className="relative rounded-2xl bg-[#0f1722]/90 border border-slate-800/80 px-3 py-2 shadow-sm overflow-hidden transition-all"
    >
      <div className="flex items-center justify-between mb-1.5 px-0.5">
        <div className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-[#10d97b]/80 animate-pulse" />
          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-semibold">
            {slotLabel}
          </span>
        </div>
        <button
          type="button"
          onClick={() => {
            setAdStatus('loading');
            setFrameKey((k) => k + 1);
          }}
          title="Reload ad banner"
          aria-label="Reload ad"
          className="p-1 rounded-lg text-slate-500 hover:text-slate-300 hover:bg-slate-800/60 transition-colors"
        >
          <RefreshCw className="w-3 h-3" />
        </button>
      </div>

      {/* Adsterra Visual Banner Frame (Clean same-origin iframe with proper dimensions) */}
      <div
        data-testid={`adsterra-iframe-slot-${placement}`}
        className={`w-full rounded-xl bg-slate-950/60 border border-slate-800/40 p-1 flex items-center justify-center overflow-hidden ${iframeHeightClass}`}
      >
        <iframe
          key={frameKey}
          title={`${slotLabel} (${activeZoneKey})`}
          src={`/adsterra-frame.html?slot=${placement}&zone=${encodeURIComponent(activeZoneKey)}`}
          scrolling="no"
          loading="lazy"
          className={`w-full ${iframeHeightClass} border-0 overflow-hidden bg-transparent`}
        />
      </div>
    </div>
  );
};
